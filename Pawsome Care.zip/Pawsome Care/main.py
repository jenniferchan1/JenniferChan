"""
============================================================
  PET DAILY CARE TRACKER
  Stanford Code in Place — Final Project
  
  Concepts used:
    - Lists & Dictionaries
    - File I/O (CSV read/write)
    - Functions
    - Loops & Conditionals
    - User Input & Text Processing
============================================================
"""

import csv
import os
from datetime import datetime

# ──────────────────────────────────────────────
#  CONSTANTS — daily routine templates
# ──────────────────────────────────────────────

DOG_ROUTINE = [
    {"id": "d1", "time": "7:00 AM",  "task": "Morning wake-up",   "detail": "Potty break + fresh water"},
    {"id": "d2", "time": "7:30 AM",  "task": "Breakfast",          "detail": "Morning meal"},
    {"id": "d3", "time": "8:15 AM",  "task": "Morning walk",       "detail": "20-30 min on-leash"},
    {"id": "d4", "time": "12:30 PM", "task": "Midday play break",  "detail": "Fetch or tug, 10-15 min"},
    {"id": "d5", "time": "1:00 PM",  "task": "Lunch snack",        "detail": "Light snack or half portion"},
    {"id": "d6", "time": "3:30 PM",  "task": "Afternoon walk",     "detail": "20-30 min socialisation"},
    {"id": "d7", "time": "5:30 PM",  "task": "Dinner",             "detail": "Evening meal"},
    {"id": "d8", "time": "6:15 PM",  "task": "Dinner walk",        "detail": "15-20 min wind-down pace"},
    {"id": "d9", "time": "9:00 PM",  "task": "Bedtime routine",    "detail": "Final potty + settle"},
]

CAT_ROUTINE = [
    {"id": "c1", "time": "7:00 AM",  "task": "Morning wake-up",   "detail": "Fresh water + litter check"},
    {"id": "c2", "time": "7:30 AM",  "task": "Breakfast",          "detail": "Morning wet food"},
    {"id": "c3", "time": "8:00 AM",  "task": "Morning play",       "detail": "Wand or laser toy, 10 min"},
    {"id": "c4", "time": "12:00 PM", "task": "Midday snack",       "detail": "Dry kibble top-up"},
    {"id": "c5", "time": "1:00 PM",  "task": "Lunch play break",   "detail": "Puzzle feeder or toy rotation"},
    {"id": "c6", "time": "3:00 PM",  "task": "Grooming check",     "detail": "Brush coat, check ears & paws"},
    {"id": "c7", "time": "5:30 PM",  "task": "Dinner",             "detail": "Evening wet food"},
    {"id": "c8", "time": "6:15 PM",  "task": "Evening play",       "detail": "Active play, 15 min"},
    {"id": "c9", "time": "9:00 PM",  "task": "Bedtime",            "detail": "Final litter check + settle"},
]

LOG_FILE = "care_log.csv"
LOG_HEADERS = ["date", "pet_name", "type", "time", "duration_mins", "amount", "mood", "notes"]

VALID_TYPES = ["feeding", "walk", "play", "medication", "grooming", "vet", "other"]
VALID_MOODS = ["happy", "calm", "tired", "anxious", "unwell"]


# ──────────────────────────────────────────────
#  HELPER UTILITIES
# ──────────────────────────────────────────────

def clear():
    """Clear the terminal screen."""
    os.system("cls" if os.name == "nt" else "clear")


def print_header(title):
    """Print a consistent section header."""
    print()
    print("=" * 50)
    print(f"  {title}")
    print("=" * 50)


def print_divider():
    print("-" * 50)


def today():
    """Return today's date as a string."""
    return datetime.now().strftime("%Y-%m-%d")


def current_time():
    """Return current time as HH:MM string."""
    return datetime.now().strftime("%H:%M")


def ask(prompt, valid_options=None, allow_blank=False):
    """
    Ask the user for input with optional validation.
    
    Parameters:
        prompt        (str)  : the question to show
        valid_options (list) : if given, only accept values in this list
        allow_blank   (bool) : if True, empty input is accepted
    
    Returns:
        str : the validated user input (lowercased if options given)
    """
    while True:
        answer = input(f"  {prompt} ").strip()
        if allow_blank and answer == "":
            return answer
        if not answer:
            print("  Please enter a value.")
            continue
        if valid_options:
            if answer.lower() in [o.lower() for o in valid_options]:
                return answer.lower()
            else:
                print(f"  Invalid choice. Options: {', '.join(valid_options)}")
                continue
        return answer


# ──────────────────────────────────────────────
#  FILE I/O — Save & Load
# ──────────────────────────────────────────────

def load_log():
    """
    Load all care log entries from the CSV file.
    
    Returns:
        list of dict : each row is one log entry
    
    FILE I/O concept:
        - Opens file in "r" (read) mode
        - csv.DictReader maps each row to a dict automatically
        - try/except handles missing file on first run
    """
    entries = []
    try:
        with open(LOG_FILE, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                entries.append(row)   # each row is already a dict
    except FileNotFoundError:
        pass   # no file yet — that's fine, start fresh
    return entries


def save_log(entries):
    """
    Save all log entries back to the CSV file.
    
    Parameters:
        entries (list of dict) : all log entries to write
    
    FILE I/O concept:
        - Opens file in "w" (write) mode — overwrites each time
        - csv.DictWriter writes the header row then all data rows
    """
    with open(LOG_FILE, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=LOG_HEADERS)
        writer.writeheader()         # writes the column names
        writer.writerows(entries)    # writes every dict as a row


def append_entry(entry):
    """
    Add one new entry to the log file without rewriting everything.
    
    Parameters:
        entry (dict) : a single log entry
    
    FILE I/O concept:
        - "a" mode appends to the end of the file
        - Only writes the header if the file doesn't exist yet
    """
    file_exists = os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=LOG_HEADERS)
        if not file_exists:
            writer.writeheader()    # first-time: write header
        writer.writerow(entry)


# ──────────────────────────────────────────────
#  FEATURE 1 — View Today's Routine
# ──────────────────────────────────────────────

def view_routine(pet_name, routine, checked_ids):
    """
    Display the full daily routine for a pet with checkmarks.
    
    Parameters:
        pet_name    (str)  : "Dog" or "Cat"
        routine     (list) : list of routine dicts
        checked_ids (list) : task IDs the user has ticked off
    
    Concepts used:
        - enumerate() for numbered display
        - list membership check with 'in'
        - f-strings for formatting
    """
    print_header(f"{pet_name.upper()} — Daily Routine")
    
    sections = {"Morning": [], "Afternoon": [], "Evening": []}
    for task in routine:
        hour = int(task["time"].split(":")[0])
        am_pm = task["time"].split(" ")[1]
        if am_pm == "AM":
            sections["Morning"].append(task)
        elif hour < 5:
            sections["Afternoon"].append(task)
        else:
            sections["Evening"].append(task)

    # simpler split by index
    for i, section in enumerate(["Morning", "Afternoon", "Evening"]):
        chunk = routine[i*3 : i*3+3]
        print(f"\n  -- {section} --")
        for task in chunk:
            done = "[x]" if task["id"] in checked_ids else "[ ]"
            print(f"  {done}  {task['time']:<10}  {task['task']:<22}  {task['detail']}")

    done_count = len(checked_ids)
    total = len(routine)
    print(f"\n  Progress: {done_count}/{total} tasks done today")
    print_divider()


# ──────────────────────────────────────────────
#  FEATURE 2 — Tick Off a Task
# ──────────────────────────────────────────────

def tick_task(pet_name, routine, checked_ids):
    """
    Let the user mark a routine task as done.
    
    Parameters:
        pet_name    (str)  : display name
        routine     (list) : list of routine task dicts
        checked_ids (list) : mutated in-place to add completed id
    
    Concepts used:
        - Looping over a list with enumerate
        - List .append() and membership check
        - int() type conversion on user input
    """
    print_header(f"Tick off a task — {pet_name}")
    for i, task in enumerate(routine):
        done = " (done)" if task["id"] in checked_ids else ""
        print(f"  {i+1}. {task['time']:<10} {task['task']}{done}")

    print()
    choice = ask("Enter task number (or 0 to cancel):")
    
    try:
        index = int(choice) - 1
    except ValueError:
        print("  Please enter a number.")
        return

    if choice == "0":
        return
    if 0 <= index < len(routine):
        task = routine[index]
        if task["id"] in checked_ids:
            checked_ids.remove(task["id"])
            print(f"  Unmarked: {task['task']}")
        else:
            checked_ids.append(task["id"])
            print(f"  Done: {task['task']} ✓")
    else:
        print("  Invalid number.")
    
    input("\n  Press Enter to continue...")


# ──────────────────────────────────────────────
#  FEATURE 3 — Log a Care Note
# ──────────────────────────────────────────────

def log_care_note(pet_name):
    """
    Collect details from the user and save a care note to file.
    
    Parameters:
        pet_name (str) : which pet this note is for
    
    Concepts used:
        - Building a dict from user input
        - Calling append_entry() to write to CSV
        - allow_blank=True for optional fields
    """
    print_header(f"Log a Care Note — {pet_name}")
    print(f"  Types: {', '.join(VALID_TYPES)}")
    
    log_type  = ask("Type:", valid_options=VALID_TYPES)
    log_time  = ask(f"Time (HH:MM) [press Enter for now = {current_time()}]:", allow_blank=True)
    if log_time == "":
        log_time = current_time()
    
    duration  = ask("Duration in minutes (or Enter to skip):", allow_blank=True)
    amount    = ask("Amount / dose (or Enter to skip):", allow_blank=True)
    
    print(f"  Moods: {', '.join(VALID_MOODS)}")
    mood      = ask("Mood (or Enter to skip):", allow_blank=True)
    notes     = ask("Notes (or Enter to skip):", allow_blank=True)

    entry = {
        "date":          today(),
        "pet_name":      pet_name,
        "type":          log_type,
        "time":          log_time,
        "duration_mins": duration,
        "amount":        amount,
        "mood":          mood,
        "notes":         notes,
    }

    append_entry(entry)
    print(f"\n  Saved! '{log_type}' note logged for {pet_name} at {log_time}.")
    input("\n  Press Enter to continue...")


# ──────────────────────────────────────────────
#  FEATURE 4 — View Care Log History
# ──────────────────────────────────────────────

def view_log(pet_name, filter_date=None):
    """
    Display past care log entries for a pet.
    
    Parameters:
        pet_name    (str)  : filter log by this pet name
        filter_date (str)  : if given, only show entries for this date
    
    Concepts used:
        - Loading list of dicts from CSV
        - List comprehension for filtering
        - Conditional string formatting
    """
    print_header(f"Care Log — {pet_name}")
    
    all_entries = load_log()
    
    # Filter: only this pet's entries
    entries = [e for e in all_entries if e["pet_name"].lower() == pet_name.lower()]
    
    if filter_date:
        entries = [e for e in entries if e["date"] == filter_date]
    
    if not entries:
        print("  No entries found.")
    else:
        for e in entries:
            extras = []
            if e["duration_mins"]: extras.append(f"{e['duration_mins']} min")
            if e["amount"]:        extras.append(e["amount"])
            if e["mood"]:          extras.append(e["mood"])
            extra_str = "  |  " + "  ·  ".join(extras) if extras else ""
            
            print(f"\n  [{e['date']}  {e['time']}]  {e['type'].upper()}{extra_str}")
            if e["notes"]:
                print(f"    Notes: {e['notes']}")
    
    print_divider()
    input("\n  Press Enter to continue...")


# ──────────────────────────────────────────────
#  FEATURE 5 — Add or Edit a Pet Profile
# ──────────────────────────────────────────────

def setup_pet(pets):
    """
    Add a new pet to the session's pet list.
    
    Parameters:
        pets (list of dict) : mutated in-place with new pet
    
    Concepts used:
        - Building a dict from user input
        - list .append()
    """
    print_header("Add a Pet")
    name    = ask("Pet's name:")
    species = ask("Species:", valid_options=["dog", "cat", "rabbit", "bird", "other"])
    age     = ask("Age in years:")
    breed   = ask("Breed (or Enter to skip):", allow_blank=True)
    
    pet = {
        "name":    name.capitalize(),
        "species": species,
        "age":     age,
        "breed":   breed,
    }
    pets.append(pet)
    print(f"\n  {pet['name']} the {species} has been added!")
    input("\n  Press Enter to continue...")


# ──────────────────────────────────────────────
#  PET MENU — actions for one pet
# ──────────────────────────────────────────────

def pet_menu(pet, checked_ids):
    """
    Show the sub-menu for a specific pet.
    
    Parameters:
        pet         (dict) : the pet's profile dict
        checked_ids (list) : today's completed task IDs
    """
    name = pet["name"]
    routine = DOG_ROUTINE if pet["species"] == "dog" else CAT_ROUTINE

    while True:
        clear()
        view_routine(name, routine, checked_ids)
        
        print(f"\n  What would you like to do for {name}?")
        print("  1. Tick off a task")
        print("  2. Log a care note")
        print("  3. View care log (today)")
        print("  4. View full care log")
        print("  5. Back to main menu")
        
        choice = ask("Choose:", valid_options=["1","2","3","4","5"])
        
        if choice == "1":
            tick_task(name, routine, checked_ids)
        elif choice == "2":
            log_care_note(name)
        elif choice == "3":
            view_log(name, filter_date=today())
        elif choice == "4":
            view_log(name)
        elif choice == "5":
            break


# ──────────────────────────────────────────────
#  MAIN PROGRAM
# ──────────────────────────────────────────────

def main():
    """
    Entry point — runs the main menu loop.
    
    Data structures:
        pets        = list of pet profile dicts
        checked     = dict mapping pet name → list of ticked task IDs
    
    Loop:
        while True keeps the program running until the user quits.
    """
    clear()
    print_header("PET DAILY CARE TRACKER")
    print("  Welcome! Let's look after your pets.")
    print("  (Stanford Code in Place — Final Project)")
    input("\n  Press Enter to begin...")

    # ── seed with sample pets so the app works immediately ──
    pets = [
        {"name": "Buddy", "species": "dog", "age": "3", "breed": "Golden Retriever"},
        {"name": "Luna",  "species": "cat", "age": "2", "breed": "Tabby"},
    ]
    
    # checked[pet_name] = list of task IDs ticked today
    checked = {p["name"]: [] for p in pets}

    while True:
        clear()
        print_header("MAIN MENU")
        print(f"  Today: {today()}\n")

        if pets:
            print("  Your pets:")
            for i, pet in enumerate(pets):
                name = pet["name"]
                species = pet["species"].capitalize()
                done = len(checked.get(name, []))
                total = len(DOG_ROUTINE) if pet["species"] == "dog" else len(CAT_ROUTINE)
                print(f"    {i+1}. {name} ({species}, age {pet['age']}) — {done}/{total} tasks done")
        else:
            print("  No pets yet. Add one below!")

        print()
        print("  a. Select a pet")
        print("  b. Add a new pet")
        print("  c. View all logs for today")
        print("  q. Quit & save")
        print()

        choice = ask("Choose:", valid_options=["a","b","c","q"])

        if choice == "a":
            if not pets:
                print("  No pets yet — add one first!")
                input("  Press Enter...")
                continue
            print()
            for i, p in enumerate(pets):
                print(f"  {i+1}. {p['name']}")
            sel = ask(f"Enter pet number (1-{len(pets)}):")
            try:
                idx = int(sel) - 1
                if 0 <= idx < len(pets):
                    pet = pets[idx]
                    if pet["name"] not in checked:
                        checked[pet["name"]] = []
                    pet_menu(pet, checked[pet["name"]])
                else:
                    print("  Invalid number.")
            except ValueError:
                print("  Please enter a number.")

        elif choice == "b":
            setup_pet(pets)
            for p in pets:
                if p["name"] not in checked:
                    checked[p["name"]] = []

        elif choice == "c":
            all_entries = load_log()
            today_entries = [e for e in all_entries if e["date"] == today()]
            print_header(f"All logs for {today()}")
            if not today_entries:
                print("  Nothing logged today yet.")
            else:
                for e in today_entries:
                    print(f"  [{e['time']}]  {e['pet_name']:<10}  {e['type']:<12}  {e['notes'][:40] if e['notes'] else ''}")
            input("\n  Press Enter to continue...")

        elif choice == "q":
            print("\n  Goodbye! Your log has been saved to care_log.csv")
            print("  See you tomorrow! 🐾")
            break


if __name__ == "__main__":
    main()
